﻿namespace Esercitazione.Repo
{
    public class Class1
    {

    }
}