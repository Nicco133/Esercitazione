﻿using Esercitazione.Data;
using System.Reflection.Metadata;
using Esercitazione.Domain;

namespace Esercitazione.Repository
{
    public class DocumentRepository
    {
        private readonly EsercitazioneDbContext _context;

        public DocumentRepository(EsercitazioneDbContext context)
        {
            _context = context;
        }

        public void Create(string name, string description)
        {
            _context.Documents.Add(new Domain.Document { Name=name , Description = description});
            _context.SaveChanges();
        }

        public Domain.Document Read(string name)
        {
            return _context.Documents.Where(d => name.Equals(d.Name)).First();
        }

        public void Update(string name, string description)
        {
            _context.Add(new Domain.Document { Name = name, Description = description });
            _context.SaveChanges();
        }

        public void Delete(string name, string description)
        {
            _context.Add(new Domain.Document { Name = name, Description = description });
            _context.SaveChanges();
        }


    }
}