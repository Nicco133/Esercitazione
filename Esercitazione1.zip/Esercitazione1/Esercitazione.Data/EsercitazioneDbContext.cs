﻿using Microsoft.EntityFrameworkCore;
using Esercitazione.Domain;
using System.Reflection.Metadata;

namespace Esercitazione.Data
{
    public class EsercitazioneDbContext : DbContext
    {
        public DbSet<Domain.Document> Documents { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Domain.Document>(
                eb =>
                {
                    eb.HasKey(d => d.Id).HasName("ID");
                    eb.Property(d => d.Name).HasColumnType("varchar(50)").HasColumnName("name");
                    eb.Property(d => d.Description).HasColumnType("varchar(50)").HasColumnName("description");
                });
        }
    }
}