﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Numerics;

namespace Esercitazione.Domain
{
    public class Document
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }

    }
}